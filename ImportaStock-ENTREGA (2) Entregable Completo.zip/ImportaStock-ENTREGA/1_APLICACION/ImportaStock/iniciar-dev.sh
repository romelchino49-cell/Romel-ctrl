#!/bin/sh
cd "$(dirname "$0")"
docker compose stop frontend backend >/dev/null 2>&1
docker compose -f docker-compose.yml -f docker-compose.dev.yml up -d keycloak-db keycloak backend-dev web-dev
echo "Primera vez: 5-8 min. Avance: docker compose -f docker-compose.yml -f docker-compose.dev.yml logs -f web-dev"
echo "Abrir http://localhost:4200 (admin1 / Admin123!). Frontend: se recarga solo al guardar. Backend: docker compose -f docker-compose.yml -f docker-compose.dev.yml restart backend-dev"
