@echo off
echo === ImportaStock MODO DESARROLLO ===
echo Deteniendo la version normal (si estaba encendida)...
docker compose stop frontend backend >nul 2>&1
docker compose -f docker-compose.yml -f docker-compose.dev.yml up -d keycloak-db keycloak backend-dev web-dev
echo.
echo La primera vez tarda 5-8 minutos (descarga dependencias). Para ver el avance:
echo    docker compose -f docker-compose.yml -f docker-compose.dev.yml logs -f web-dev
echo Cuando diga "Local: http://localhost:4200" abre  http://localhost:4200   (admin1 / Admin123!)
echo.
echo CAMBIOS: guarda el archivo y el navegador se actualiza solo (frontend).
echo Para cambios de backend:  reiniciar-backend-dev.bat
pause
