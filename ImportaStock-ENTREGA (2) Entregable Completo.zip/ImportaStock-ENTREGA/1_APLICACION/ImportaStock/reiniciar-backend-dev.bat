@echo off
docker compose -f docker-compose.yml -f docker-compose.dev.yml restart backend-dev
echo Backend reiniciando (20-40 s). Luego recarga el navegador.
pause
