#!/bin/sh
cd "$(dirname "$0")"
docker compose -f docker-compose.yml -f docker-compose.oracle.yml up -d --build
echo "App: http://localhost:4200 (admin1 / Admin123!) · Keycloak: http://localhost:8081 · Oracle: localhost:1522/FREEPDB1 (importastock/importastock)"
