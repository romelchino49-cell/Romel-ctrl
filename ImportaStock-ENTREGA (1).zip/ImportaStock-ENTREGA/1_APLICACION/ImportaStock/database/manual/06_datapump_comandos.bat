@echo off
REM ImportaStock - 06 - Data Pump (EXPDP / IMPDP). Ejecutar en el CMD de Windows.
REM Antes: mkdir C:\dp_importastock  y ejecutar 06_datapump_system.sql como SYSTEM.
REM Usa el usuario local DPADMIN (ver LEEME_EJECUCION.md, paso 6).

echo === 8.1 EXPORTACION ===
expdp importastock/importastock@localhost:1521/FREEPDB1 schemas=importastock directory=dp_importastock dumpfile=importastock.dmp logfile=exp_importastock.log reuse_dumpfiles=y

echo === 8.3 ARCHIVOS GENERADOS ===
dir C:\dp_importastock

echo === 8.2 IMPORTACION hacia IMPORTASTOCK_COPY ===
impdp dpadmin/dpadmin@localhost:1521/FREEPDB1 directory=dp_importastock dumpfile=importastock.dmp logfile=imp_importastock.log remap_schema=importastock:importastock_copy

echo === Log de importacion (debe terminar sin errores) ===
type C:\dp_importastock\imp_importastock.log
REM 8.4 VERIFICACION: ejecutar las consultas finales de 06_datapump_system.sql en SQL Developer.
