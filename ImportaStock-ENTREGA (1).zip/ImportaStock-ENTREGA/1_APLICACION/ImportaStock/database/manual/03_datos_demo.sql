-- =====================================================================
-- ImportaStock · 03 · DATOS DE DEMOSTRACIÓN (ejecutar como IMPORTASTOCK, después de 02)
-- Datos ficticios (DEMO). Totales, saldos y stock calculados de forma coherente:
--   importacion.total = SUM(detalle.subtotal) · cantidad_recibida = aceptada + dañada
--   producto.stock_actual = saldo del último movimiento del producto
-- Ejecutar con "Ejecutar script" (F5).
-- =====================================================================
WHENEVER SQLERROR EXIT FAILURE
BEGIN
  IF USER <> 'IMPORTASTOCK' THEN
    RAISE_APPLICATION_ERROR(-20999, 'CONEXION INCORRECTA: abre este script con la conexion IMPORTASTOCK (ahora estas como ' || USER || ')');
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE
SET ECHO ON

-- Categorías
INSERT INTO categoria (nombre, descripcion) VALUES ('Electrónica', 'Dispositivos y accesorios');
INSERT INTO categoria (nombre, descripcion) VALUES ('Textil', 'Telas y prendas');
INSERT INTO categoria (nombre, descripcion) VALUES ('Herramientas', 'Herramientas manuales y eléctricas');

-- Proveedores (China/Japón -> p_asia · Italia/Alemania/España -> p_europa · resto -> p_otros)
INSERT INTO proveedor (codigo, razon_social, pais, contacto, email) VALUES ('PRV-001', 'Shenzhen Tech Co. (DEMO)', 'China', 'Contacto demo', 'li@demo.test');
INSERT INTO proveedor (codigo, razon_social, pais, contacto, email) VALUES ('PRV-002', 'Milano Tessuti S.p.A. (DEMO)', 'Italia', 'Contacto demo', 'rossi@demo.test');
INSERT INTO proveedor (codigo, razon_social, pais, contacto, email) VALUES ('PRV-003', 'Hamburg Werkzeug GmbH (DEMO)', 'Alemania', 'Contacto demo', 'klein@demo.test');
INSERT INTO proveedor (codigo, razon_social, pais, contacto, email) VALUES ('PRV-004', 'Tokyo Precision Ltd. (DEMO)', 'Japón', 'Contacto demo', 'sato@demo.test');
INSERT INTO proveedor (codigo, razon_social, pais, contacto, email) VALUES ('PRV-005', 'Madrid Textiles S.L. (DEMO)', 'España', 'Contacto demo', 'garcia@demo.test');
INSERT INTO proveedor (codigo, razon_social, pais, contacto, email) VALUES ('PRV-006', 'Houston Supply Inc. (DEMO)', 'Estados Unidos', 'Contacto demo', 'smith@demo.test');
INSERT INTO proveedor (codigo, razon_social, pais, contacto, email) VALUES ('PRV-007', 'Hanoi Garments JSC (DEMO)', 'Vietnam', 'Contacto demo', 'nguyen@demo.test');

-- Productos (stock_actual = stock final tras los movimientos de más abajo)
INSERT INTO producto (sku, nombre, categoria_id, marca, pais_origen, unidad, precio_referencia, stock_minimo, stock_actual)
  VALUES ('ELE-001', 'Cargador USB-C 65W', (SELECT id FROM categoria WHERE nombre = 'Electrónica'), 'VoltX', 'China', 'UND', 18.50, 20, 390);
INSERT INTO producto (sku, nombre, categoria_id, marca, pais_origen, unidad, precio_referencia, stock_minimo, stock_actual)
  VALUES ('ELE-002', 'Auriculares inalámbricos', (SELECT id FROM categoria WHERE nombre = 'Electrónica'), 'SoundGo', 'China', 'UND', 32.00, 15, 320);
INSERT INTO producto (sku, nombre, categoria_id, marca, pais_origen, unidad, precio_referencia, stock_minimo, stock_actual)
  VALUES ('ELE-003', 'Cámara de seguridad WiFi', (SELECT id FROM categoria WHERE nombre = 'Electrónica'), 'VisionHome', 'Japón', 'UND', 46.00, 20, 18);
INSERT INTO producto (sku, nombre, categoria_id, marca, pais_origen, unidad, precio_referencia, stock_minimo, stock_actual)
  VALUES ('TEX-001', 'Tela de algodón 150cm', (SELECT id FROM categoria WHERE nombre = 'Textil'), 'TessuPro', 'Italia', 'MTS', 6.40, 100, 840);
INSERT INTO producto (sku, nombre, categoria_id, marca, pais_origen, unidad, precio_referencia, stock_minimo, stock_actual)
  VALUES ('TEX-002', 'Tela de lino 140cm', (SELECT id FROM categoria WHERE nombre = 'Textil'), 'TessuPro', 'España', 'MTS', 7.60, 80, 500);
INSERT INTO producto (sku, nombre, categoria_id, marca, pais_origen, unidad, precio_referencia, stock_minimo, stock_actual)
  VALUES ('HER-001', 'Taladro percutor 800W', (SELECT id FROM categoria WHERE nombre = 'Herramientas'), 'WerkPro', 'Alemania', 'UND', 74.90, 10, 53);
INSERT INTO producto (sku, nombre, categoria_id, marca, pais_origen, unidad, precio_referencia, stock_minimo, stock_actual)
  VALUES ('HER-002', 'Juego de llaves 40 piezas', (SELECT id FROM categoria WHERE nombre = 'Herramientas'), 'WerkPro', 'Alemania', 'SET', 39.00, 12, 10);
INSERT INTO producto (sku, nombre, categoria_id, marca, pais_origen, unidad, precio_referencia, stock_minimo, stock_actual)
  VALUES ('HER-003', 'Nivel láser 15 m', (SELECT id FROM categoria WHERE nombre = 'Herramientas'), 'WerkPro', 'Alemania', 'UND', 24.00, 8, 40);

-- Importaciones (cabecera) con total calculado
INSERT INTO importacion (numero, proveedor_id, fecha_registro, fecha_prevista, moneda, referencia, estado, total)
  VALUES ('IMP-2025-001', (SELECT id FROM proveedor WHERE codigo = 'PRV-001'), DATE '2025-11-20', DATE '2025-12-10', 'USD', 'OC-CN-1120', 'COMPLETA', 7635.00);
INSERT INTO importacion (numero, proveedor_id, fecha_registro, fecha_prevista, moneda, referencia, estado, total)
  VALUES ('IMP-2026-001', (SELECT id FROM proveedor WHERE codigo = 'PRV-002'), DATE '2026-01-15', DATE '2026-01-30', 'EUR', 'OC-IT-0115', 'COMPLETA', 9400.00);
INSERT INTO importacion (numero, proveedor_id, fecha_registro, fecha_prevista, moneda, referencia, estado, total)
  VALUES ('IMP-2026-002', (SELECT id FROM proveedor WHERE codigo = 'PRV-003'), DATE '2026-03-10', DATE '2026-03-28', 'EUR', 'OC-DE-0310', 'COMPLETA', 7800.00);
INSERT INTO importacion (numero, proveedor_id, fecha_registro, fecha_prevista, moneda, referencia, estado, total)
  VALUES ('IMP-2026-003', (SELECT id FROM proveedor WHERE codigo = 'PRV-004'), DATE '2026-08-05', DATE '2026-08-22', 'USD', 'OC-JP-0805', 'COMPLETA', 7120.00);
INSERT INTO importacion (numero, proveedor_id, fecha_registro, fecha_prevista, moneda, referencia, estado, total)
  VALUES ('IMP-2026-004', (SELECT id FROM proveedor WHERE codigo = 'PRV-001'), DATE '2026-10-12', DATE '2026-11-30', 'USD', 'OC-CN-1012', 'PARCIAL', 12200.00);
INSERT INTO importacion (numero, proveedor_id, fecha_registro, fecha_prevista, moneda, referencia, estado, total)
  VALUES ('IMP-2026-005', (SELECT id FROM proveedor WHERE codigo = 'PRV-005'), DATE '2026-11-03', DATE '2026-12-15', 'EUR', 'OC-ES-1103', 'REGISTRADA', 7880.00);

-- Detalle de importación (subtotal = cantidad x precio)
INSERT INTO detalle_importacion (importacion_id, producto_id, cantidad_solicitada, cantidad_recibida, precio_unitario, subtotal)
  VALUES ((SELECT id FROM importacion WHERE numero = 'IMP-2025-001'), (SELECT id FROM producto WHERE sku = 'ELE-001'), 200, 200, 16.80, 3360.00);
INSERT INTO detalle_importacion (importacion_id, producto_id, cantidad_solicitada, cantidad_recibida, precio_unitario, subtotal)
  VALUES ((SELECT id FROM importacion WHERE numero = 'IMP-2025-001'), (SELECT id FROM producto WHERE sku = 'ELE-002'), 150, 150, 28.50, 4275.00);
INSERT INTO detalle_importacion (importacion_id, producto_id, cantidad_solicitada, cantidad_recibida, precio_unitario, subtotal)
  VALUES ((SELECT id FROM importacion WHERE numero = 'IMP-2026-001'), (SELECT id FROM producto WHERE sku = 'TEX-001'), 1000, 1000, 5.80, 5800.00);
INSERT INTO detalle_importacion (importacion_id, producto_id, cantidad_solicitada, cantidad_recibida, precio_unitario, subtotal)
  VALUES ((SELECT id FROM importacion WHERE numero = 'IMP-2026-001'), (SELECT id FROM producto WHERE sku = 'TEX-002'), 500, 500, 7.20, 3600.00);
INSERT INTO detalle_importacion (importacion_id, producto_id, cantidad_solicitada, cantidad_recibida, precio_unitario, subtotal)
  VALUES ((SELECT id FROM importacion WHERE numero = 'IMP-2026-002'), (SELECT id FROM producto WHERE sku = 'HER-001'), 60, 60, 68.00, 4080.00);
INSERT INTO detalle_importacion (importacion_id, producto_id, cantidad_solicitada, cantidad_recibida, precio_unitario, subtotal)
  VALUES ((SELECT id FROM importacion WHERE numero = 'IMP-2026-002'), (SELECT id FROM producto WHERE sku = 'HER-002'), 80, 80, 35.50, 2840.00);
INSERT INTO detalle_importacion (importacion_id, producto_id, cantidad_solicitada, cantidad_recibida, precio_unitario, subtotal)
  VALUES ((SELECT id FROM importacion WHERE numero = 'IMP-2026-002'), (SELECT id FROM producto WHERE sku = 'HER-003'), 40, 40, 22.00, 880.00);
INSERT INTO detalle_importacion (importacion_id, producto_id, cantidad_solicitada, cantidad_recibida, precio_unitario, subtotal)
  VALUES ((SELECT id FROM importacion WHERE numero = 'IMP-2026-003'), (SELECT id FROM producto WHERE sku = 'ELE-003'), 120, 120, 45.00, 5400.00);
INSERT INTO detalle_importacion (importacion_id, producto_id, cantidad_solicitada, cantidad_recibida, precio_unitario, subtotal)
  VALUES ((SELECT id FROM importacion WHERE numero = 'IMP-2026-003'), (SELECT id FROM producto WHERE sku = 'ELE-001'), 100, 100, 17.20, 1720.00);
INSERT INTO detalle_importacion (importacion_id, producto_id, cantidad_solicitada, cantidad_recibida, precio_unitario, subtotal)
  VALUES ((SELECT id FROM importacion WHERE numero = 'IMP-2026-004'), (SELECT id FROM producto WHERE sku = 'ELE-002'), 300, 180, 29.00, 8700.00);
INSERT INTO detalle_importacion (importacion_id, producto_id, cantidad_solicitada, cantidad_recibida, precio_unitario, subtotal)
  VALUES ((SELECT id FROM importacion WHERE numero = 'IMP-2026-004'), (SELECT id FROM producto WHERE sku = 'ELE-001'), 200, 120, 17.50, 3500.00);
INSERT INTO detalle_importacion (importacion_id, producto_id, cantidad_solicitada, cantidad_recibida, precio_unitario, subtotal)
  VALUES ((SELECT id FROM importacion WHERE numero = 'IMP-2026-005'), (SELECT id FROM producto WHERE sku = 'TEX-001'), 800, 0, 6.10, 4880.00);
INSERT INTO detalle_importacion (importacion_id, producto_id, cantidad_solicitada, cantidad_recibida, precio_unitario, subtotal)
  VALUES ((SELECT id FROM importacion WHERE numero = 'IMP-2026-005'), (SELECT id FROM producto WHERE sku = 'TEX-002'), 400, 0, 7.50, 3000.00);

-- Recepciones (cabecera)
INSERT INTO recepcion (numero, importacion_id, fecha, responsable, observaciones)
  VALUES ('REC-2025-001', (SELECT id FROM importacion WHERE numero = 'IMP-2025-001'), TIMESTAMP '2025-12-10 09:30:00', 'operador1', 'Recepción demo');
INSERT INTO recepcion (numero, importacion_id, fecha, responsable, observaciones)
  VALUES ('REC-2026-001', (SELECT id FROM importacion WHERE numero = 'IMP-2026-001'), TIMESTAMP '2026-01-28 10:15:00', 'operador1', 'Recepción demo');
INSERT INTO recepcion (numero, importacion_id, fecha, responsable, observaciones)
  VALUES ('REC-2026-002', (SELECT id FROM importacion WHERE numero = 'IMP-2026-002'), TIMESTAMP '2026-03-25 11:00:00', 'operador1', 'Recepción demo');
INSERT INTO recepcion (numero, importacion_id, fecha, responsable, observaciones)
  VALUES ('REC-2026-003', (SELECT id FROM importacion WHERE numero = 'IMP-2026-003'), TIMESTAMP '2026-08-20 08:45:00', 'operador1', 'Recepción demo');
INSERT INTO recepcion (numero, importacion_id, fecha, responsable, observaciones)
  VALUES ('REC-2026-004', (SELECT id FROM importacion WHERE numero = 'IMP-2026-004'), TIMESTAMP '2026-10-25 14:20:00', 'operador1', 'Recepción demo');

-- Detalle de recepción (unidades aceptadas y dañadas por línea)
INSERT INTO detalle_recepcion (recepcion_id, producto_id, detalle_importacion_id, aceptada, danada)
  VALUES ((SELECT id FROM recepcion WHERE numero = 'REC-2025-001'), (SELECT id FROM producto WHERE sku = 'ELE-001'),
          (SELECT di.id FROM detalle_importacion di WHERE di.importacion_id = (SELECT id FROM importacion WHERE numero = 'IMP-2025-001') AND di.producto_id = (SELECT id FROM producto WHERE sku = 'ELE-001')), 195, 5);
INSERT INTO detalle_recepcion (recepcion_id, producto_id, detalle_importacion_id, aceptada, danada)
  VALUES ((SELECT id FROM recepcion WHERE numero = 'REC-2025-001'), (SELECT id FROM producto WHERE sku = 'ELE-002'),
          (SELECT di.id FROM detalle_importacion di WHERE di.importacion_id = (SELECT id FROM importacion WHERE numero = 'IMP-2025-001') AND di.producto_id = (SELECT id FROM producto WHERE sku = 'ELE-002')), 150, 0);
INSERT INTO detalle_recepcion (recepcion_id, producto_id, detalle_importacion_id, aceptada, danada)
  VALUES ((SELECT id FROM recepcion WHERE numero = 'REC-2026-001'), (SELECT id FROM producto WHERE sku = 'TEX-001'),
          (SELECT di.id FROM detalle_importacion di WHERE di.importacion_id = (SELECT id FROM importacion WHERE numero = 'IMP-2026-001') AND di.producto_id = (SELECT id FROM producto WHERE sku = 'TEX-001')), 990, 10);
INSERT INTO detalle_recepcion (recepcion_id, producto_id, detalle_importacion_id, aceptada, danada)
  VALUES ((SELECT id FROM recepcion WHERE numero = 'REC-2026-001'), (SELECT id FROM producto WHERE sku = 'TEX-002'),
          (SELECT di.id FROM detalle_importacion di WHERE di.importacion_id = (SELECT id FROM importacion WHERE numero = 'IMP-2026-001') AND di.producto_id = (SELECT id FROM producto WHERE sku = 'TEX-002')), 500, 0);
INSERT INTO detalle_recepcion (recepcion_id, producto_id, detalle_importacion_id, aceptada, danada)
  VALUES ((SELECT id FROM recepcion WHERE numero = 'REC-2026-002'), (SELECT id FROM producto WHERE sku = 'HER-001'),
          (SELECT di.id FROM detalle_importacion di WHERE di.importacion_id = (SELECT id FROM importacion WHERE numero = 'IMP-2026-002') AND di.producto_id = (SELECT id FROM producto WHERE sku = 'HER-001')), 58, 2);
INSERT INTO detalle_recepcion (recepcion_id, producto_id, detalle_importacion_id, aceptada, danada)
  VALUES ((SELECT id FROM recepcion WHERE numero = 'REC-2026-002'), (SELECT id FROM producto WHERE sku = 'HER-002'),
          (SELECT di.id FROM detalle_importacion di WHERE di.importacion_id = (SELECT id FROM importacion WHERE numero = 'IMP-2026-002') AND di.producto_id = (SELECT id FROM producto WHERE sku = 'HER-002')), 80, 0);
INSERT INTO detalle_recepcion (recepcion_id, producto_id, detalle_importacion_id, aceptada, danada)
  VALUES ((SELECT id FROM recepcion WHERE numero = 'REC-2026-002'), (SELECT id FROM producto WHERE sku = 'HER-003'),
          (SELECT di.id FROM detalle_importacion di WHERE di.importacion_id = (SELECT id FROM importacion WHERE numero = 'IMP-2026-002') AND di.producto_id = (SELECT id FROM producto WHERE sku = 'HER-003')), 40, 0);
INSERT INTO detalle_recepcion (recepcion_id, producto_id, detalle_importacion_id, aceptada, danada)
  VALUES ((SELECT id FROM recepcion WHERE numero = 'REC-2026-003'), (SELECT id FROM producto WHERE sku = 'ELE-003'),
          (SELECT di.id FROM detalle_importacion di WHERE di.importacion_id = (SELECT id FROM importacion WHERE numero = 'IMP-2026-003') AND di.producto_id = (SELECT id FROM producto WHERE sku = 'ELE-003')), 118, 2);
INSERT INTO detalle_recepcion (recepcion_id, producto_id, detalle_importacion_id, aceptada, danada)
  VALUES ((SELECT id FROM recepcion WHERE numero = 'REC-2026-003'), (SELECT id FROM producto WHERE sku = 'ELE-001'),
          (SELECT di.id FROM detalle_importacion di WHERE di.importacion_id = (SELECT id FROM importacion WHERE numero = 'IMP-2026-003') AND di.producto_id = (SELECT id FROM producto WHERE sku = 'ELE-001')), 100, 0);
INSERT INTO detalle_recepcion (recepcion_id, producto_id, detalle_importacion_id, aceptada, danada)
  VALUES ((SELECT id FROM recepcion WHERE numero = 'REC-2026-004'), (SELECT id FROM producto WHERE sku = 'ELE-002'),
          (SELECT di.id FROM detalle_importacion di WHERE di.importacion_id = (SELECT id FROM importacion WHERE numero = 'IMP-2026-004') AND di.producto_id = (SELECT id FROM producto WHERE sku = 'ELE-002')), 170, 10);
INSERT INTO detalle_recepcion (recepcion_id, producto_id, detalle_importacion_id, aceptada, danada)
  VALUES ((SELECT id FROM recepcion WHERE numero = 'REC-2026-004'), (SELECT id FROM producto WHERE sku = 'ELE-001'),
          (SELECT di.id FROM detalle_importacion di WHERE di.importacion_id = (SELECT id FROM importacion WHERE numero = 'IMP-2026-004') AND di.producto_id = (SELECT id FROM producto WHERE sku = 'ELE-001')), 115, 5);

-- Movimientos de inventario (entradas por recepción y salidas/ajustes), con saldo
INSERT INTO movimiento_inventario (producto_id, tipo, cantidad, saldo, fecha, responsable, origen)
  VALUES ((SELECT id FROM producto WHERE sku = 'ELE-001'), 'ENTRADA', 195, 195, TIMESTAMP '2025-12-10 09:30:00', 'operador1', 'RECEPCION REC-2025-001');
INSERT INTO movimiento_inventario (producto_id, tipo, cantidad, saldo, fecha, responsable, origen)
  VALUES ((SELECT id FROM producto WHERE sku = 'ELE-002'), 'ENTRADA', 150, 150, TIMESTAMP '2025-12-10 09:30:00', 'operador1', 'RECEPCION REC-2025-001');
INSERT INTO movimiento_inventario (producto_id, tipo, cantidad, saldo, fecha, responsable, origen)
  VALUES ((SELECT id FROM producto WHERE sku = 'TEX-001'), 'ENTRADA', 990, 990, TIMESTAMP '2026-01-28 10:15:00', 'operador1', 'RECEPCION REC-2026-001');
INSERT INTO movimiento_inventario (producto_id, tipo, cantidad, saldo, fecha, responsable, origen)
  VALUES ((SELECT id FROM producto WHERE sku = 'TEX-002'), 'ENTRADA', 500, 500, TIMESTAMP '2026-01-28 10:15:00', 'operador1', 'RECEPCION REC-2026-001');
INSERT INTO movimiento_inventario (producto_id, tipo, cantidad, saldo, fecha, responsable, origen)
  VALUES ((SELECT id FROM producto WHERE sku = 'TEX-001'), 'SALIDA', 150, 840, TIMESTAMP '2026-02-10 16:00:00', 'admin1', 'AJUSTE: despacho a taller');
INSERT INTO movimiento_inventario (producto_id, tipo, cantidad, saldo, fecha, responsable, origen)
  VALUES ((SELECT id FROM producto WHERE sku = 'HER-001'), 'ENTRADA', 58, 58, TIMESTAMP '2026-03-25 11:00:00', 'operador1', 'RECEPCION REC-2026-002');
INSERT INTO movimiento_inventario (producto_id, tipo, cantidad, saldo, fecha, responsable, origen)
  VALUES ((SELECT id FROM producto WHERE sku = 'HER-002'), 'ENTRADA', 80, 80, TIMESTAMP '2026-03-25 11:00:00', 'operador1', 'RECEPCION REC-2026-002');
INSERT INTO movimiento_inventario (producto_id, tipo, cantidad, saldo, fecha, responsable, origen)
  VALUES ((SELECT id FROM producto WHERE sku = 'HER-003'), 'ENTRADA', 40, 40, TIMESTAMP '2026-03-25 11:00:00', 'operador1', 'RECEPCION REC-2026-002');
INSERT INTO movimiento_inventario (producto_id, tipo, cantidad, saldo, fecha, responsable, origen)
  VALUES ((SELECT id FROM producto WHERE sku = 'ELE-001'), 'ENTRADA', 100, 295, TIMESTAMP '2026-08-20 08:45:00', 'operador1', 'RECEPCION REC-2026-003');
INSERT INTO movimiento_inventario (producto_id, tipo, cantidad, saldo, fecha, responsable, origen)
  VALUES ((SELECT id FROM producto WHERE sku = 'ELE-003'), 'ENTRADA', 118, 118, TIMESTAMP '2026-08-20 08:45:00', 'operador1', 'RECEPCION REC-2026-003');
INSERT INTO movimiento_inventario (producto_id, tipo, cantidad, saldo, fecha, responsable, origen)
  VALUES ((SELECT id FROM producto WHERE sku = 'HER-001'), 'SALIDA', 5, 53, TIMESTAMP '2026-09-03 10:10:00', 'admin1', 'AJUSTE: merma por golpe');
INSERT INTO movimiento_inventario (producto_id, tipo, cantidad, saldo, fecha, responsable, origen)
  VALUES ((SELECT id FROM producto WHERE sku = 'ELE-003'), 'SALIDA', 100, 18, TIMESTAMP '2026-09-15 12:00:00', 'admin1', 'AJUSTE: despacho a cliente');
INSERT INTO movimiento_inventario (producto_id, tipo, cantidad, saldo, fecha, responsable, origen)
  VALUES ((SELECT id FROM producto WHERE sku = 'HER-002'), 'SALIDA', 70, 10, TIMESTAMP '2026-10-05 09:00:00', 'admin1', 'AJUSTE: despacho a cliente');
INSERT INTO movimiento_inventario (producto_id, tipo, cantidad, saldo, fecha, responsable, origen)
  VALUES ((SELECT id FROM producto WHERE sku = 'ELE-001'), 'ENTRADA', 115, 410, TIMESTAMP '2026-10-25 14:20:00', 'operador1', 'RECEPCION REC-2026-004');
INSERT INTO movimiento_inventario (producto_id, tipo, cantidad, saldo, fecha, responsable, origen)
  VALUES ((SELECT id FROM producto WHERE sku = 'ELE-002'), 'ENTRADA', 170, 320, TIMESTAMP '2026-10-25 14:20:00', 'operador1', 'RECEPCION REC-2026-004');
INSERT INTO movimiento_inventario (producto_id, tipo, cantidad, saldo, fecha, responsable, origen)
  VALUES ((SELECT id FROM producto WHERE sku = 'ELE-001'), 'SALIDA', 20, 390, TIMESTAMP '2026-11-05 15:30:00', 'admin1', 'AJUSTE: muestras comerciales');

COMMIT;

-- Conteo de filas cargadas
SELECT 'CATEGORIA' tabla, COUNT(*) filas FROM categoria UNION ALL SELECT 'PROVEEDOR', COUNT(*) FROM proveedor UNION ALL SELECT 'PRODUCTO', COUNT(*) FROM producto
UNION ALL SELECT 'IMPORTACION', COUNT(*) FROM importacion UNION ALL SELECT 'DETALLE_IMPORTACION', COUNT(*) FROM detalle_importacion
UNION ALL SELECT 'RECEPCION', COUNT(*) FROM recepcion UNION ALL SELECT 'DETALLE_RECEPCION', COUNT(*) FROM detalle_recepcion
UNION ALL SELECT 'MOVIMIENTO_INVENTARIO', COUNT(*) FROM movimiento_inventario;
