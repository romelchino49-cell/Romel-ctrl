-- =====================================================================
-- ImportaStock · 00 · LIMPIEZA del esquema SYSTEM
-- Ejecutar SOLO con la conexión IMPORTASTOCK_SYSTEM (F5).
-- Borra de SYSTEM las 8 tablas y los objetos PL/SQL de ImportaStock que se crearon
-- por error en ese esquema. No toca ninguna otra tabla de SYSTEM.
-- =====================================================================
SET SERVEROUTPUT ON
BEGIN
  IF USER <> 'SYSTEM' THEN
    RAISE_APPLICATION_ERROR(-20998, 'Este script es solo para la conexión SYSTEM (estás como ' || USER || ')');
  END IF;
  FOR t IN (SELECT column_value n FROM TABLE(sys.odcivarchar2list(
      'DETALLE_RECEPCION','RECEPCION','MOVIMIENTO_INVENTARIO','DETALLE_IMPORTACION',
      'IMPORTACION','PRODUCTO','PROVEEDOR','CATEGORIA'))) LOOP
    BEGIN EXECUTE IMMEDIATE 'DROP TABLE system.' || t.n || ' CASCADE CONSTRAINTS PURGE';
          DBMS_OUTPUT.PUT_LINE('Tabla borrada: ' || t.n);
    EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('No existía: ' || t.n); END;
  END LOOP;
  FOR o IN (SELECT column_value n FROM TABLE(sys.odcivarchar2list(
      'FN_TOTAL_IMPORTACION','FN_PENDIENTE_LINEA','FN_ESTADO_STOCK'))) LOOP
    BEGIN EXECUTE IMMEDIATE 'DROP FUNCTION system.' || o.n;
          DBMS_OUTPUT.PUT_LINE('Función borrada: ' || o.n);
    EXCEPTION WHEN OTHERS THEN NULL; END;
  END LOOP;
  FOR o IN (SELECT column_value n FROM TABLE(sys.odcivarchar2list(
      'SP_REGISTRAR_MOVIMIENTO','SP_RECALCULAR_TOTAL','SP_REGISTRAR_RECEPCION',
      'SP_LISTAR_STOCK_BAJO','SP_RESUMEN_IMPORTACIONES'))) LOOP
    BEGIN EXECUTE IMMEDIATE 'DROP PROCEDURE system.' || o.n;
          DBMS_OUTPUT.PUT_LINE('Procedimiento borrado: ' || o.n);
    EXCEPTION WHEN OTHERS THEN NULL; END;
  END LOOP;
END;
/
-- Debe devolver 0 filas:
SELECT table_name FROM user_tables
WHERE  table_name IN ('CATEGORIA','PROVEEDOR','PRODUCTO','IMPORTACION','DETALLE_IMPORTACION',
                      'RECEPCION','DETALLE_RECEPCION','MOVIMIENTO_INVENTARIO');
