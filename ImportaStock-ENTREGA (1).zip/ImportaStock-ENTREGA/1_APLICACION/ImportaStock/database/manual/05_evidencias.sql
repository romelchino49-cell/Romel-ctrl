-- =====================================================================
-- ImportaStock · 05 · EVIDENCIAS DE FUNCIONAMIENTO (ejecutar como IMPORTASTOCK)
-- Ejecutar BLOQUE POR BLOQUE: selecciona el bloque y pulsa F5 (Ejecutar script)
-- para ver los PROMPT y la salida de DBMS_OUTPUT en el panel "Salida de script";
-- los SELECT también se pueden ejecutar con F9 (cuadrícula). Haz una captura
-- por bloque (se indica "CAPTURA n" en cada uno).
-- Orden previo obligatorio: 01 (SYSTEM) -> 02 -> 03 -> 04.
-- =====================================================================
WHENEVER SQLERROR EXIT FAILURE
BEGIN
  IF USER <> 'IMPORTASTOCK' THEN
    RAISE_APPLICATION_ERROR(-20999, 'CONEXION INCORRECTA: abre este script con la conexion IMPORTASTOCK (ahora estas como ' || USER || ')');
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE
SET SERVEROUTPUT ON SIZE UNLIMITED
SET PAGESIZE 100
SET LINESIZE 200
SET FEEDBACK ON

---------------------------------------------------------------------
PROMPT === CAPTURA 1 · Tablas, restricciones y datos cargados ===
---------------------------------------------------------------------
SELECT table_name, partitioned FROM user_tables ORDER BY table_name;

SELECT table_name, constraint_name, constraint_type, status
FROM   user_constraints
WHERE  constraint_type IN ('P', 'U', 'R', 'C') AND generated = 'USER NAME'
ORDER  BY table_name, constraint_type, constraint_name;

SELECT 'CATEGORIA' tabla, COUNT(*) filas FROM categoria
UNION ALL SELECT 'PROVEEDOR', COUNT(*) FROM proveedor
UNION ALL SELECT 'PRODUCTO', COUNT(*) FROM producto
UNION ALL SELECT 'IMPORTACION', COUNT(*) FROM importacion
UNION ALL SELECT 'DETALLE_IMPORTACION', COUNT(*) FROM detalle_importacion
UNION ALL SELECT 'RECEPCION', COUNT(*) FROM recepcion
UNION ALL SELECT 'DETALLE_RECEPCION', COUNT(*) FROM detalle_recepcion
UNION ALL SELECT 'MOVIMIENTO_INVENTARIO', COUNT(*) FROM movimiento_inventario;

---------------------------------------------------------------------
PROMPT === CAPTURA 2 · Consultas del negocio (JOIN cabecera-detalle) ===
---------------------------------------------------------------------
-- Importaciones con proveedor, estado y total
SELECT i.numero, pv.razon_social, pv.pais, i.fecha_registro, i.moneda, i.estado, i.total
FROM   importacion i JOIN proveedor pv ON pv.id = i.proveedor_id
ORDER  BY i.fecha_registro;

-- Detalle de una importación (relación N:M resuelta)
SELECT i.numero, p.sku, p.nombre, d.cantidad_solicitada, d.cantidad_recibida, d.precio_unitario, d.subtotal
FROM   importacion i
JOIN   detalle_importacion d ON d.importacion_id = i.id
JOIN   producto p ON p.id = d.producto_id
WHERE  i.numero = 'IMP-2026-004';

-- Recepciones con unidades aceptadas y dañadas
SELECT r.numero AS recepcion, i.numero AS importacion, p.sku, dr.aceptada, dr.danada, r.responsable
FROM   recepcion r
JOIN   importacion i ON i.id = r.importacion_id
JOIN   detalle_recepcion dr ON dr.recepcion_id = r.id
JOIN   producto p ON p.id = dr.producto_id
ORDER  BY r.fecha, p.sku;

-- Inventario actual frente al mínimo
SELECT sku, nombre, stock_actual, stock_minimo, fn_estado_stock(id) AS estado
FROM   producto ORDER BY sku;

-- Kardex de un producto
SELECT m.fecha, m.tipo, m.cantidad, m.saldo, m.responsable, m.origen
FROM   movimiento_inventario m JOIN producto p ON p.id = m.producto_id
WHERE  p.sku = 'ELE-001' ORDER BY m.fecha, m.id;

---------------------------------------------------------------------
PROMPT === CAPTURA 3 · Verificación de consistencia (deben salir 0 filas) ===
---------------------------------------------------------------------
-- Total de cabecera distinto de la suma del detalle
SELECT i.numero, i.total, fn_total_importacion(i.id) AS suma_detalle
FROM   importacion i WHERE i.total <> fn_total_importacion(i.id);

-- Stock distinto del saldo del último movimiento
SELECT p.sku, p.stock_actual,
       (SELECT m.saldo FROM movimiento_inventario m
         WHERE m.producto_id = p.id ORDER BY m.fecha DESC, m.id DESC FETCH FIRST 1 ROW ONLY) AS ultimo_saldo
FROM   producto p
WHERE  p.stock_actual <> NVL((SELECT m.saldo FROM movimiento_inventario m
         WHERE m.producto_id = p.id ORDER BY m.fecha DESC, m.id DESC FETCH FIRST 1 ROW ONLY), 0);

-- cantidad_recibida distinta de lo registrado en detalle_recepcion (aceptada + dañada)
SELECT d.id, d.cantidad_recibida,
       (SELECT NVL(SUM(dr.aceptada + dr.danada), 0) FROM detalle_recepcion dr WHERE dr.detalle_importacion_id = d.id) AS en_recepciones
FROM   detalle_importacion d
WHERE  NVL(d.cantidad_recibida, 0) <>
       (SELECT NVL(SUM(dr.aceptada + dr.danada), 0) FROM detalle_recepcion dr WHERE dr.detalle_importacion_id = d.id);

---------------------------------------------------------------------
PROMPT === CAPTURA 4 · Estructura de particiones (sección VII) ===
---------------------------------------------------------------------
SELECT table_name, partitioning_type, interval, ref_ptn_constraint_name
FROM   user_part_tables ORDER BY table_name;

EXEC DBMS_STATS.GATHER_SCHEMA_STATS(USER);

SELECT table_name, partition_position AS pos, partition_name, tablespace_name, num_rows, high_value
FROM   user_tab_partitions
ORDER  BY table_name, partition_position;

---------------------------------------------------------------------
PROMPT === CAPTURA 5 · Consultas sobre una sola partición ===
---------------------------------------------------------------------
SELECT codigo, razon_social, pais FROM proveedor PARTITION (p_asia);
SELECT codigo, razon_social, pais FROM proveedor PARTITION (p_europa);
SELECT codigo, razon_social, pais FROM proveedor PARTITION (p_otros);

-- Importaciones y movimientos del mes de octubre de 2026 (partición creada automáticamente)
SELECT numero, fecha_registro, estado, total FROM importacion PARTITION FOR (DATE '2026-10-15');
SELECT fecha, tipo, cantidad, saldo, origen FROM movimiento_inventario PARTITION FOR (DATE '2026-10-15');

-- Importaciones anteriores a 2026 (p_historico)
SELECT numero, fecha_registro, estado FROM importacion PARTITION (p_historico);

---------------------------------------------------------------------
PROMPT === CAPTURA 6 · Poda de particiones (buscar PARTITION RANGE SINGLE / PARTITION LIST SINGLE) ===
---------------------------------------------------------------------
EXPLAIN PLAN FOR
  SELECT * FROM movimiento_inventario
  WHERE  fecha >= DATE '2026-10-01' AND fecha < DATE '2026-11-01';
SELECT plan_table_output FROM TABLE(DBMS_XPLAN.DISPLAY(NULL, NULL, 'TYPICAL'));

EXPLAIN PLAN FOR
  SELECT * FROM proveedor WHERE pais = 'China';
SELECT plan_table_output FROM TABLE(DBMS_XPLAN.DISPLAY(NULL, NULL, 'TYPICAL'));

---------------------------------------------------------------------
PROMPT === CAPTURA 7 · Almacenamiento: segmentos por tablespace (sección VI) ===
---------------------------------------------------------------------
SELECT tablespace_name, segment_type, COUNT(*) AS segmentos, ROUND(SUM(bytes)/1024) AS kb
FROM   user_segments
GROUP  BY tablespace_name, segment_type
ORDER  BY tablespace_name, segment_type;

SELECT segment_name, partition_name, segment_type, tablespace_name, ROUND(bytes/1024) AS kb
FROM   user_segments
WHERE  segment_name IN ('MOVIMIENTO_INVENTARIO', 'IMPORTACION', 'PROVEEDOR')
ORDER  BY segment_name, partition_name;

SELECT index_name, table_name, tablespace_name FROM user_indexes
WHERE  tablespace_name IS NOT NULL ORDER BY table_name, index_name;

---------------------------------------------------------------------
PROMPT === CAPTURA 8 · PL/SQL: funciones y cursores ===
---------------------------------------------------------------------
SELECT numero, total, fn_total_importacion(id) AS total_calculado FROM importacion ORDER BY numero;

SELECT d.id AS detalle_id, i.numero, p.sku, fn_pendiente_linea(d.id) AS pendiente
FROM   detalle_importacion d JOIN importacion i ON i.id = d.importacion_id JOIN producto p ON p.id = d.producto_id
WHERE  i.estado <> 'COMPLETA' ORDER BY i.numero, p.sku;

EXEC sp_listar_stock_bajo;

VARIABLE rc REFCURSOR
EXEC sp_resumen_importaciones(:rc);
PRINT rc

---------------------------------------------------------------------
PROMPT === CAPTURA 9 · PL/SQL: recepción transaccional (completa IMP-2026-004) ===
---------------------------------------------------------------------
-- ANTES
SELECT i.numero, i.estado, p.sku, d.cantidad_solicitada, d.cantidad_recibida, p.stock_actual
FROM   importacion i JOIN detalle_importacion d ON d.importacion_id = i.id JOIN producto p ON p.id = d.producto_id
WHERE  i.numero = 'IMP-2026-004' ORDER BY p.sku;

DECLARE
  v_d_aud NUMBER; v_d_car NUMBER;
BEGIN
  SELECT d.id INTO v_d_aud FROM detalle_importacion d JOIN importacion i ON i.id = d.importacion_id
   JOIN producto p ON p.id = d.producto_id WHERE i.numero = 'IMP-2026-004' AND p.sku = 'ELE-002';
  SELECT d.id INTO v_d_car FROM detalle_importacion d JOIN importacion i ON i.id = d.importacion_id
   JOIN producto p ON p.id = d.producto_id WHERE i.numero = 'IMP-2026-004' AND p.sku = 'ELE-001';
  sp_registrar_recepcion('REC-2026-005', v_d_aud, 115, 5, 'operador1');   -- pendiente 120
  sp_registrar_recepcion('REC-2026-005', v_d_car, 80, 0, 'operador1');    -- pendiente 80
  COMMIT;
  DBMS_OUTPUT.PUT_LINE('Recepción REC-2026-005 registrada y confirmada (COMMIT).');
END;
/

-- DESPUÉS: la importación queda COMPLETA, el stock sube y hay nuevos movimientos de ENTRADA
SELECT i.numero, i.estado, p.sku, d.cantidad_solicitada, d.cantidad_recibida, p.stock_actual
FROM   importacion i JOIN detalle_importacion d ON d.importacion_id = i.id JOIN producto p ON p.id = d.producto_id
WHERE  i.numero = 'IMP-2026-004' ORDER BY p.sku;

SELECT m.fecha, p.sku, m.tipo, m.cantidad, m.saldo, m.origen
FROM   movimiento_inventario m JOIN producto p ON p.id = m.producto_id
WHERE  m.origen = 'RECEPCION REC-2026-005' ORDER BY p.sku;

---------------------------------------------------------------------
PROMPT === CAPTURA 10 · Reglas de negocio que el motor rechaza (errores ESPERADOS) ===
---------------------------------------------------------------------
DECLARE
  v_det NUMBER; v_det_c NUMBER; v_prod NUMBER;
  PROCEDURE prueba(p_titulo VARCHAR2, p_sql VARCHAR2) IS
  BEGIN
    EXECUTE IMMEDIATE p_sql;
    DBMS_OUTPUT.PUT_LINE('[FALLO DE LA PRUEBA] ' || p_titulo || ' -> no dio error');
    ROLLBACK;
  EXCEPTION WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('[OK] ' || RPAD(p_titulo, 52) || ' -> ' || SUBSTR(SQLERRM, 1, 110));
    ROLLBACK;
  END;
BEGIN
  -- Restricciones declarativas
  prueba('SKU duplicado (UNIQUE)',
         'INSERT INTO producto (sku, nombre, categoria_id, stock_actual) VALUES (''ELE-001'', ''Duplicado'', (SELECT MIN(id) FROM categoria), 0)');
  prueba('Categoría inexistente (FK)',
         'INSERT INTO producto (sku, nombre, categoria_id, stock_actual) VALUES (''XXX-999'', ''Sin categoría'', 99999, 0)');
  prueba('Moneda no permitida (CHECK)',
         'INSERT INTO importacion (numero, proveedor_id, fecha_registro, moneda, estado, total) VALUES (''IMP-ERR-1'', (SELECT MIN(id) FROM proveedor), SYSDATE, ''JPY'', ''REGISTRADA'', 0)');
  prueba('Eliminar proveedor con importaciones (FK)',
         'DELETE FROM proveedor WHERE codigo = ''PRV-001''');
  prueba('Eliminar producto con detalle (FK)',
         'DELETE FROM producto WHERE sku = ''ELE-001''');
  -- Triggers
  prueba('Stock negativo por UPDATE directo (trigger)',
         'UPDATE producto SET stock_actual = -1 WHERE sku = ''HER-002''');
  prueba('Eliminar importación COMPLETA (trigger)',
         'DELETE FROM importacion WHERE numero = ''IMP-2026-001''');
  -- Procedimientos
  SELECT id INTO v_prod FROM producto WHERE sku = 'HER-002';
  prueba('Salida mayor al stock (sp_registrar_movimiento)',
         'BEGIN sp_registrar_movimiento(' || v_prod || ', ''SALIDA'', 9999, ''admin1'', ''PRUEBA''); END;');
  SELECT d.id INTO v_det FROM detalle_importacion d JOIN importacion i ON i.id = d.importacion_id
   JOIN producto p ON p.id = d.producto_id WHERE i.numero = 'IMP-2026-005' AND p.sku = 'TEX-001';
  prueba('Recibir más de lo pendiente (sp_registrar_recepcion)',
         'BEGIN sp_registrar_recepcion(''REC-ERR-1'', ' || v_det || ', 900, 0, ''operador1''); END;');
  SELECT MIN(d.id) INTO v_det_c FROM detalle_importacion d JOIN importacion i ON i.id = d.importacion_id
   WHERE i.numero = 'IMP-2026-001';
  prueba('Recibir en importación ya COMPLETA',
         'BEGIN sp_registrar_recepcion(''REC-ERR-2'', ' || v_det_c || ', 1, 0, ''operador1''); END;');
END;
/

---------------------------------------------------------------------
PROMPT === CAPTURA 11 · Trigger de subtotal (se calcula solo en la BD) ===
---------------------------------------------------------------------
-- Se inserta una línea con subtotal 999 (incorrecto): el trigger lo corrige a cantidad x precio.
INSERT INTO importacion (numero, proveedor_id, fecha_registro, moneda, estado, total)
VALUES ('IMP-PRUEBA', (SELECT id FROM proveedor WHERE codigo = 'PRV-006'), DATE '2026-11-17', 'USD', 'REGISTRADA', 0);
INSERT INTO detalle_importacion (importacion_id, producto_id, cantidad_solicitada, cantidad_recibida, precio_unitario, subtotal)
VALUES ((SELECT id FROM importacion WHERE numero = 'IMP-PRUEBA'), (SELECT id FROM producto WHERE sku = 'HER-003'), 10, 0, 2.50, 999);
DECLARE v_id NUMBER;
BEGIN
  SELECT id INTO v_id FROM importacion WHERE numero = 'IMP-PRUEBA';
  sp_recalcular_total(v_id);
END;
/
SELECT i.numero, d.cantidad_solicitada, d.precio_unitario, d.subtotal AS subtotal_calculado_por_trigger, i.total
FROM   importacion i JOIN detalle_importacion d ON d.importacion_id = i.id WHERE i.numero = 'IMP-PRUEBA';
-- Se deshace la prueba:
ROLLBACK;
SELECT COUNT(*) AS filas_de_prueba_restantes FROM importacion WHERE numero = 'IMP-PRUEBA';
