-- =====================================================================
-- ImportaStock · 01 · TABLESPACES, DATAFILES y usuario (ejecutar como SYSTEM)
-- Conexión SQL Developer: IMPORTASTOCK_SYSTEM (SYSTEM · localhost · 1521 · FREEPDB1)
-- Ejecutar con "Ejecutar script" (F5).
-- NOTA: la ruta de los datafiles se detecta sola (Windows, Linux o Docker).
-- =====================================================================
SET ECHO ON
SET SERVEROUTPUT ON

-- A) Ruta física donde Oracle guarda los datafiles de la PDB
SELECT name FROM v$datafile WHERE UPPER(name) LIKE '%SYSTEM01%' OR UPPER(name) LIKE '%USERS01%';

-- B) Limpieza previa (solo si se repite la instalación)
BEGIN
  EXECUTE IMMEDIATE 'DROP USER importastock_copy CASCADE';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
-- (Las tablas del esquema se recrean desde 02_tablas_particionadas.sql, que ya las borra en orden.)

-- C) Tablespaces del proyecto (3 espacios lógicos, 1 datafile cada uno)
--    ts_imp_data : tablas del negocio
--    ts_imp_idx  : índices (PK, UNIQUE y de apoyo)
--    ts_imp_mov  : movimientos de inventario (tabla de mayor crecimiento) e histórico
--    La carpeta de los datafiles se toma de los datafiles existentes de la PDB, por lo que
--    el script funciona igual en Windows, Linux y Docker.
DECLARE
  v_dir VARCHAR2(500);
  PROCEDURE crear(p_sql VARCHAR2) IS
  BEGIN EXECUTE IMMEDIATE p_sql;
  EXCEPTION WHEN OTHERS THEN
    IF SQLCODE = -1543 THEN DBMS_OUTPUT.PUT_LINE('Ya existe: ' || SUBSTR(p_sql, 1, 60));
    ELSE RAISE; END IF;
  END;
BEGIN
  SELECT REGEXP_REPLACE(name, '[^/\\]+$', '') INTO v_dir
  FROM  (SELECT name FROM v$datafile ORDER BY file#) WHERE ROWNUM = 1;
  crear('CREATE TABLESPACE ts_imp_data DATAFILE ''' || v_dir || 'ts_imp_data01.dbf'' SIZE 100M AUTOEXTEND ON NEXT 20M MAXSIZE 1G');
  crear('CREATE TABLESPACE ts_imp_idx  DATAFILE ''' || v_dir || 'ts_imp_idx01.dbf''  SIZE 50M  AUTOEXTEND ON NEXT 10M MAXSIZE 500M');
  crear('CREATE TABLESPACE ts_imp_mov  DATAFILE ''' || v_dir || 'ts_imp_mov01.dbf''  SIZE 100M AUTOEXTEND ON NEXT 20M MAXSIZE 1G');
END;
/

-- D) Usuario/esquema de la aplicación (la imagen Docker ya lo crea con APP_USER;
--    aquí se crea solo si no existe y se le asignan tablespace por defecto y cuota)
DECLARE
  v NUMBER;
BEGIN
  SELECT COUNT(*) INTO v FROM dba_users WHERE username = 'IMPORTASTOCK';
  IF v = 0 THEN
    EXECUTE IMMEDIATE 'CREATE USER importastock IDENTIFIED BY importastock';
  END IF;
END;
/
ALTER USER importastock DEFAULT TABLESPACE ts_imp_data;
ALTER USER importastock QUOTA UNLIMITED ON ts_imp_data;
ALTER USER importastock QUOTA UNLIMITED ON ts_imp_idx;
ALTER USER importastock QUOTA UNLIMITED ON ts_imp_mov;
GRANT CREATE SESSION, CREATE TABLE, CREATE VIEW, CREATE SEQUENCE, CREATE PROCEDURE, CREATE TRIGGER TO importastock;

-- E) EVIDENCIA 6.4: tablespaces y datafiles creados
SELECT tablespace_name, status, contents, extent_management, segment_space_management
FROM   dba_tablespaces
WHERE  tablespace_name LIKE 'TS_IMP%' OR tablespace_name = 'USERS'
ORDER  BY tablespace_name;

SELECT tablespace_name, file_name, ROUND(bytes/1024/1024) AS mb,
       autoextensible, ROUND(maxbytes/1024/1024) AS max_mb
FROM   dba_data_files
WHERE  tablespace_name LIKE 'TS_IMP%'
ORDER  BY tablespace_name;

SELECT username, default_tablespace FROM dba_users WHERE username = 'IMPORTASTOCK';

SELECT tablespace_name, username, max_bytes
FROM   dba_ts_quotas
WHERE  username = 'IMPORTASTOCK';
