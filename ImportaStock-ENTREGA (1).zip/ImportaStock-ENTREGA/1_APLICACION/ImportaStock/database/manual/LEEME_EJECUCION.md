# ImportaStock · Base de datos Oracle y evidencias en SQL Developer

Scripts generados a partir del Informe Final BD II, el Documento ADS y el código del zip (entidades JPA, `DataSeeder`, `particionamiento-oracle.sql`).
**Importante:** estos scripts se escribieron sin acceso a una instancia Oracle, así que **no se han ejecutado todavía**. Los datos de ejemplo sí se comprobaron en una base de prueba (totales, saldos y stock coherentes), pero la sintaxis Oracle (particiones, PL/SQL, Data Pump) debes validarla al ejecutarlos. Si algún script da error, copia el mensaje y se corrige.

## 1. Levantar Oracle
```
(No aplica: usas Oracle local, no Docker.)
```

## 2. Conexiones en SQL Developer (Nueva conexión → Oracle, tipo Básico)
| Nombre | Usuario | Contraseña | Host | Puerto | Nombre de servicio |
|---|---|---|---|---|---|
| IMPORTASTOCK_SYSTEM | SYSTEM | (tu clave) | localhost | 1521 | FREEPDB1 |
| IMPORTASTOCK | importastock | importastock | localhost | 1521 | FREEPDB1 |

## 3. Orden de ejecución
(Si por error ejecutaste 02/03/04 con SYSTEM, corre primero `00_limpiar_system.sql` con la conexión SYSTEM.)
 (abrir cada archivo, F5 = Ejecutar script)
| Paso | Archivo | Conexión | Qué hace | Sección del informe |
|---|---|---|---|---|
| 1 | `01_tablespaces_y_usuario.sql` | SYSTEM | 3 tablespaces + datafiles, cuota del usuario | VI |
| 2 | `02_tablas_particionadas.sql` | importastock | 8 tablas, LIST/HASH/RANGE-INTERVAL/REFERENCE, FK de `detalle_recepcion` | IV, VII |
| 3 | `03_datos_demo.sql` | importastock | 7 proveedores, 8 productos, 6 importaciones, 5 recepciones, 16 movimientos | IV 4.3 |
| 4 | `04_plsql.sql` | importastock | 3 funciones, 4 procedimientos, 3 triggers, cursores | V |
| 5 | `05_evidencias.sql` | importastock | 11 bloques de consultas y pruebas, cada uno es una captura | IV 4.4, V, VII |
| 6 | `06_datapump_system.sql` + `06_datapump_comandos.bat` | SYSTEM + terminal | EXPDP/IMPDP y verificación | VIII |

Antes del paso 6 crear la carpeta `C:\dp_importastock`. En la PDB no se puede cambiar la clave de SYSTEM (ORA-65066): crear un usuario local `dpadmin` (DBA + DATAPUMP_EXP/IMP_FULL_DATABASE + READ,WRITE sobre el directory) y usar `impdp dpadmin/dpadmin@localhost:1521/FREEPDB1 ... remap_schema=importastock:importastock_copy`.

## 4. Capturas a tomar (todas en SQL Developer)
| Captura | Qué debe verse | Va en |
|---|---|---|
| Paso 1, consultas E | tablespaces `TS_IMP_*` y sus datafiles `.dbf` | 6.1, 6.2, 6.4 |
| Paso 2, final | lista de tablas y `user_part_tables` con LIST, HASH, RANGE, REFERENCE | 4.2, 4.4 |
| Paso 3, final | conteo de filas por tabla | 4.3 |
| 05 · Captura 1 | tablas, restricciones y filas | 4.4 |
| 05 · Captura 2 | joins cabecera-detalle, kardex | 4.3 |
| 05 · Captura 3 | las tres consultas de consistencia con 0 filas | 4.4 |
| 05 · Captura 4 y 5 | particiones, filas por partición, `PARTITION (p_asia)` | 7.3, 7.4 |
| 05 · Captura 6 | plan con `PARTITION RANGE SINGLE` / `PARTITION LIST SINGLE` | 7.4 |
| 05 · Captura 7 | segmentos por tablespace | 6.3 |
| 05 · Captura 8 a 9 | funciones, cursor, recepción transaccional antes y después | 5.2, 5.3, 5.4 |
| 05 · Captura 10 | errores esperados (`[OK] ...`) de restricciones y triggers | 5.5, 4.4 |
| 05 · Captura 11 | trigger de subtotal | 5.5 |
| Paso 6 | `expdp`/`impdp` terminando sin errores, `ls` de los `.dmp`, conteos origen = copia | 8.1 a 8.4 |

## 5. Cambios respecto al script original del proyecto (decláralos en el informe)
- `RECEPCION` y `DETALLE_RECEPCION` se crean aquí (antes las creaba Hibernate) y `detalle_importacion_id` pasa a ser **clave foránea** (recomendación de la sección X del informe).
- Se agregaron restricciones `CHECK` (moneda, estado, tipo de movimiento, stock >= 0, cantidades) que ya valida la API.
- Si luego levantas el backend con `BACKEND_PROFILE=oracle`, Hibernate (`ddl-auto: update`) usará estas tablas, y el `DataSeeder` no cargará nada porque ya hay categorías. Prueba que el backend arranque sin errores de mapeo contra estas tablas (en particular la columna `activo NUMBER(1)`).
- Los datos son ficticios (DEMO). `05_evidencias.sql` modifica datos (recepción REC-2026-005); para repetir las pruebas desde cero ejecuta de nuevo 02 y 03.
