-- =====================================================================
-- ImportaStock · 06 · DATA PUMP: preparación (ejecutar como SYSTEM, conexión IMPORTASTOCK_SYSTEM)
-- Antes, en el CMD de Windows, crear la carpeta física:  mkdir C:\dp_importastock
-- Luego ejecutar este script con F5 y seguir 06_datapump_comandos.bat
-- =====================================================================
SET ECHO ON

CREATE OR REPLACE DIRECTORY dp_importastock AS 'C:\dp_importastock';
GRANT READ, WRITE ON DIRECTORY dp_importastock TO importastock;

-- Esquema destino para demostrar la importación (copia del esquema original)
BEGIN EXECUTE IMMEDIATE 'DROP USER importastock_copy CASCADE'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
CREATE USER importastock_copy IDENTIFIED BY importastock_copy
  DEFAULT TABLESPACE ts_imp_data;
ALTER USER importastock_copy QUOTA UNLIMITED ON ts_imp_data;
ALTER USER importastock_copy QUOTA UNLIMITED ON ts_imp_idx;
ALTER USER importastock_copy QUOTA UNLIMITED ON ts_imp_mov;
GRANT CREATE SESSION, CREATE TABLE, CREATE PROCEDURE, CREATE TRIGGER, CREATE SEQUENCE TO importastock_copy;

-- EVIDENCIA 8.x: directorio y usuarios preparados
SELECT directory_name, directory_path FROM dba_directories WHERE directory_name = 'DP_IMPORTASTOCK';
SELECT username, default_tablespace FROM dba_users WHERE username LIKE 'IMPORTASTOCK%';

-- =====================================================================
-- DESPUÉS de correr expdp e impdp (06_datapump_comandos.sh), VERIFICAR (como SYSTEM):
-- Mismo número de filas en origen y copia, y mismos objetos
-- =====================================================================
SELECT 'ORIGEN' esquema, 'PROVEEDOR' tabla, COUNT(*) filas FROM importastock.proveedor
UNION ALL SELECT 'COPIA', 'PROVEEDOR', COUNT(*) FROM importastock_copy.proveedor
UNION ALL SELECT 'ORIGEN', 'PRODUCTO', COUNT(*) FROM importastock.producto
UNION ALL SELECT 'COPIA', 'PRODUCTO', COUNT(*) FROM importastock_copy.producto
UNION ALL SELECT 'ORIGEN', 'IMPORTACION', COUNT(*) FROM importastock.importacion
UNION ALL SELECT 'COPIA', 'IMPORTACION', COUNT(*) FROM importastock_copy.importacion
UNION ALL SELECT 'ORIGEN', 'DETALLE_IMPORTACION', COUNT(*) FROM importastock.detalle_importacion
UNION ALL SELECT 'COPIA', 'DETALLE_IMPORTACION', COUNT(*) FROM importastock_copy.detalle_importacion
UNION ALL SELECT 'ORIGEN', 'RECEPCION', COUNT(*) FROM importastock.recepcion
UNION ALL SELECT 'COPIA', 'RECEPCION', COUNT(*) FROM importastock_copy.recepcion
UNION ALL SELECT 'ORIGEN', 'DETALLE_RECEPCION', COUNT(*) FROM importastock.detalle_recepcion
UNION ALL SELECT 'COPIA', 'DETALLE_RECEPCION', COUNT(*) FROM importastock_copy.detalle_recepcion
UNION ALL SELECT 'ORIGEN', 'MOVIMIENTO_INVENTARIO', COUNT(*) FROM importastock.movimiento_inventario
UNION ALL SELECT 'COPIA', 'MOVIMIENTO_INVENTARIO', COUNT(*) FROM importastock_copy.movimiento_inventario;

SELECT owner, object_type, COUNT(*) objetos
FROM   dba_objects
WHERE  owner IN ('IMPORTASTOCK', 'IMPORTASTOCK_COPY') AND object_type IN ('TABLE', 'TABLE PARTITION', 'INDEX', 'TRIGGER', 'PROCEDURE', 'FUNCTION')
GROUP  BY owner, object_type ORDER BY object_type, owner;

SELECT table_owner, table_name, partition_name
FROM   dba_tab_partitions WHERE table_owner = 'IMPORTASTOCK_COPY' AND table_name = 'IMPORTACION'
ORDER  BY partition_position;
