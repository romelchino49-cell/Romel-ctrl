-- Carga automática de ImportaStock en Oracle (Docker).
SET SQLBLANKLINES ON
SET DEFINE OFF
SET ECHO OFF
CONNECT importastock/importastock@//localhost:1521/FREEPDB1
-- =====================================================================
-- ImportaStock · 04 · PL/SQL: funciones, procedimientos, cursores y triggers
-- (ejecutar como IMPORTASTOCK, después de 02 y 03). Ejecutar con F5.
-- Replican en la base de datos reglas que hoy aplica el backend Java
-- (InventarioService, RecepcionService, ImportacionService).
-- =====================================================================
WHENEVER SQLERROR EXIT FAILURE
BEGIN
  IF USER <> 'IMPORTASTOCK' THEN
    RAISE_APPLICATION_ERROR(-20999, 'CONEXION INCORRECTA: abre este script con la conexion IMPORTASTOCK (ahora estas como ' || USER || ')');
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE
SET ECHO ON
SET SERVEROUTPUT ON

-- ---------------------------------------------------------------------
-- 5.3 FUNCIONES
-- ---------------------------------------------------------------------

-- Total de una importación = suma de los subtotales de su detalle
CREATE OR REPLACE FUNCTION fn_total_importacion (p_importacion_id IN NUMBER)
RETURN NUMBER IS
  v_total NUMBER(14,2);
BEGIN
  SELECT NVL(SUM(subtotal), 0) INTO v_total
  FROM   detalle_importacion
  WHERE  importacion_id = p_importacion_id;
  RETURN v_total;
END fn_total_importacion;
/

-- Unidades aún pendientes de recibir en una línea del detalle de importación
CREATE OR REPLACE FUNCTION fn_pendiente_linea (p_detalle_id IN NUMBER)
RETURN NUMBER IS
  v_pend NUMBER;
BEGIN
  SELECT cantidad_solicitada - NVL(cantidad_recibida, 0) INTO v_pend
  FROM   detalle_importacion WHERE id = p_detalle_id;
  RETURN v_pend;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(-20010, 'La línea de importación ' || p_detalle_id || ' no existe');
END fn_pendiente_linea;
/

-- Estado del stock de un producto frente a su mínimo
CREATE OR REPLACE FUNCTION fn_estado_stock (p_producto_id IN NUMBER)
RETURN VARCHAR2 IS
  v_stock  producto.stock_actual%TYPE;
  v_minimo producto.stock_minimo%TYPE;
BEGIN
  SELECT stock_actual, stock_minimo INTO v_stock, v_minimo
  FROM   producto WHERE id = p_producto_id;
  RETURN CASE WHEN v_stock = 0 THEN 'SIN STOCK'
              WHEN v_stock < v_minimo THEN 'BAJO'
              ELSE 'OK' END;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(-20003, 'Producto inexistente: ' || p_producto_id);
END fn_estado_stock;
/

-- ---------------------------------------------------------------------
-- 5.2 PROCEDIMIENTOS ALMACENADOS
-- ---------------------------------------------------------------------

-- Única vía para cambiar el stock: actualiza producto y deja el movimiento (como InventarioService.mover)
CREATE OR REPLACE PROCEDURE sp_registrar_movimiento (
  p_producto_id IN NUMBER,
  p_tipo        IN VARCHAR2,
  p_cantidad    IN NUMBER,
  p_responsable IN VARCHAR2,
  p_origen      IN VARCHAR2
) IS
  v_stock producto.stock_actual%TYPE;
  v_nuevo NUMBER;
BEGIN
  IF p_cantidad IS NULL OR p_cantidad <= 0 THEN
    RAISE_APPLICATION_ERROR(-20001, 'La cantidad debe ser mayor que cero');
  END IF;
  IF p_tipo NOT IN ('ENTRADA', 'SALIDA') THEN
    RAISE_APPLICATION_ERROR(-20002, 'Tipo de movimiento inválido: ' || p_tipo);
  END IF;

  BEGIN
    SELECT stock_actual INTO v_stock FROM producto WHERE id = p_producto_id FOR UPDATE;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20003, 'Producto inexistente: ' || p_producto_id);
  END;

  v_nuevo := v_stock + CASE WHEN p_tipo = 'SALIDA' THEN -p_cantidad ELSE p_cantidad END;
  IF v_nuevo < 0 THEN
    RAISE_APPLICATION_ERROR(-20004, 'Stock insuficiente: disponible ' || v_stock || ', se pide ' || p_cantidad);
  END IF;

  UPDATE producto SET stock_actual = v_nuevo WHERE id = p_producto_id;
  INSERT INTO movimiento_inventario (producto_id, tipo, cantidad, saldo, fecha, responsable, origen)
  VALUES (p_producto_id, p_tipo, p_cantidad, v_nuevo, SYSDATE, p_responsable, p_origen);
END sp_registrar_movimiento;
/

-- Recalcula importacion.total a partir del detalle (usa fn_total_importacion)
CREATE OR REPLACE PROCEDURE sp_recalcular_total (p_importacion_id IN NUMBER) IS
BEGIN
  UPDATE importacion SET total = fn_total_importacion(p_importacion_id) WHERE id = p_importacion_id;
  IF SQL%ROWCOUNT = 0 THEN
    RAISE_APPLICATION_ERROR(-20005, 'Importación inexistente: ' || p_importacion_id);
  END IF;
END sp_recalcular_total;
/

-- Registra una línea de recepción (cabecera RECEPCION si no existe + DETALLE_RECEPCION),
-- suma lo recibido al detalle de importación, genera la ENTRADA de stock con las unidades
-- aceptadas y deja la importación en PARCIAL o COMPLETA (como RecepcionService.registrar).
-- La transacción la confirma o revierte quien llama (COMMIT / ROLLBACK).
CREATE OR REPLACE PROCEDURE sp_registrar_recepcion (
  p_numero      IN VARCHAR2,
  p_detalle_id  IN NUMBER,
  p_aceptada    IN NUMBER,
  p_danada      IN NUMBER,
  p_responsable IN VARCHAR2
) IS
  v_imp_id   importacion.id%TYPE;
  v_prod_id  producto.id%TYPE;
  v_estado   importacion.estado%TYPE;
  v_pend     NUMBER;
  v_rec_id   recepcion.id%TYPE;
  v_rec_imp  recepcion.importacion_id%TYPE;
  v_sin_cerrar NUMBER;
BEGIN
  IF NVL(p_aceptada, 0) + NVL(p_danada, 0) <= 0 THEN
    RAISE_APPLICATION_ERROR(-20011, 'Cantidad recibida inválida');
  END IF;

  BEGIN
    SELECT d.importacion_id, d.producto_id, d.cantidad_solicitada - NVL(d.cantidad_recibida, 0)
    INTO   v_imp_id, v_prod_id, v_pend
    FROM   detalle_importacion d WHERE d.id = p_detalle_id FOR UPDATE;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE_APPLICATION_ERROR(-20010, 'La línea de importación ' || p_detalle_id || ' no existe');
  END;

  SELECT estado INTO v_estado FROM importacion WHERE id = v_imp_id;
  IF v_estado = 'COMPLETA' THEN
    RAISE_APPLICATION_ERROR(-20012, 'La importación ya fue recibida por completo');
  END IF;
  IF p_aceptada + p_danada > v_pend THEN
    RAISE_APPLICATION_ERROR(-20013, 'Se recibe más de lo pendiente (pendiente ' || v_pend || ')');
  END IF;

  -- Cabecera: se reutiliza si ya existe el número (varias líneas por recepción)
  BEGIN
    SELECT id, importacion_id INTO v_rec_id, v_rec_imp FROM recepcion WHERE numero = p_numero;
    IF v_rec_imp <> v_imp_id THEN
      RAISE_APPLICATION_ERROR(-20014, 'El número ' || p_numero || ' pertenece a otra importación');
    END IF;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      INSERT INTO recepcion (numero, importacion_id, fecha, responsable, observaciones)
      VALUES (p_numero, v_imp_id, SYSTIMESTAMP, p_responsable, 'Registrada por sp_registrar_recepcion')
      RETURNING id INTO v_rec_id;
  END;

  INSERT INTO detalle_recepcion (recepcion_id, producto_id, detalle_importacion_id, aceptada, danada)
  VALUES (v_rec_id, v_prod_id, p_detalle_id, p_aceptada, p_danada);

  UPDATE detalle_importacion
  SET    cantidad_recibida = NVL(cantidad_recibida, 0) + p_aceptada + p_danada
  WHERE  id = p_detalle_id;

  IF p_aceptada > 0 THEN
    sp_registrar_movimiento(v_prod_id, 'ENTRADA', p_aceptada, p_responsable, 'RECEPCION ' || p_numero);
  END IF;

  SELECT COUNT(*) INTO v_sin_cerrar
  FROM   detalle_importacion
  WHERE  importacion_id = v_imp_id AND NVL(cantidad_recibida, 0) < cantidad_solicitada;

  UPDATE importacion
  SET    estado = CASE WHEN v_sin_cerrar = 0 THEN 'COMPLETA' ELSE 'PARCIAL' END
  WHERE  id = v_imp_id;
END sp_registrar_recepcion;
/

-- ---------------------------------------------------------------------
-- 5.4 CURSORES Y ESTRUCTURAS DE CONTROL
-- ---------------------------------------------------------------------

-- Cursor explícito + FOR + IF: lista por consola los productos bajo su stock mínimo
CREATE OR REPLACE PROCEDURE sp_listar_stock_bajo IS
  CURSOR c_bajo IS
    SELECT p.sku, p.nombre, p.stock_actual, p.stock_minimo
    FROM   producto p
    WHERE  p.stock_actual < p.stock_minimo
    ORDER  BY (p.stock_minimo - p.stock_actual) DESC;
  v_n NUMBER := 0;
BEGIN
  FOR r IN c_bajo LOOP
    v_n := v_n + 1;
    DBMS_OUTPUT.PUT_LINE(RPAD(r.sku, 8) || RPAD(r.nombre, 30) ||
                         ' stock=' || r.stock_actual || ' mínimo=' || r.stock_minimo ||
                         ' faltan=' || (r.stock_minimo - r.stock_actual));
  END LOOP;
  IF v_n = 0 THEN
    DBMS_OUTPUT.PUT_LINE('Ningún producto está bajo su stock mínimo.');
  ELSE
    DBMS_OUTPUT.PUT_LINE('Total de productos bajo mínimo: ' || v_n);
  END IF;
END sp_listar_stock_bajo;
/

-- Cursor de referencia (SYS_REFCURSOR): devuelve el resumen solicitado vs recibido por importación
CREATE OR REPLACE PROCEDURE sp_resumen_importaciones (p_cursor OUT SYS_REFCURSOR) IS
BEGIN
  OPEN p_cursor FOR
    SELECT i.numero, pv.razon_social, i.estado,
           SUM(d.cantidad_solicitada)           AS solicitado,
           SUM(NVL(d.cantidad_recibida, 0))     AS recibido,
           i.total
    FROM   importacion i
    JOIN   proveedor pv ON pv.id = i.proveedor_id
    JOIN   detalle_importacion d ON d.importacion_id = i.id
    GROUP  BY i.numero, pv.razon_social, i.estado, i.total
    ORDER  BY i.numero;
END sp_resumen_importaciones;
/

-- ---------------------------------------------------------------------
-- 5.5 TRIGGERS
-- ---------------------------------------------------------------------

-- 1) El subtotal de cada línea se calcula siempre en la base de datos
CREATE OR REPLACE TRIGGER trg_detimp_subtotal
BEFORE INSERT OR UPDATE OF cantidad_solicitada, precio_unitario ON detalle_importacion
FOR EACH ROW
BEGIN
  :NEW.subtotal := ROUND(NVL(:NEW.cantidad_solicitada, 0) * NVL(:NEW.precio_unitario, 0), 2);
END trg_detimp_subtotal;
/

-- 2) El stock nunca puede quedar negativo (segunda barrera, además del CHECK)
CREATE OR REPLACE TRIGGER trg_producto_stock
BEFORE UPDATE OF stock_actual ON producto
FOR EACH ROW
WHEN (NEW.stock_actual < 0)
BEGIN
  RAISE_APPLICATION_ERROR(-20020, 'El stock de ' || :OLD.sku || ' no puede quedar negativo');
END trg_producto_stock;
/

-- 3) Solo se puede eliminar una importación que aún no tiene recepciones (estado REGISTRADA)
CREATE OR REPLACE TRIGGER trg_importacion_no_borrar
BEFORE DELETE ON importacion
FOR EACH ROW
WHEN (OLD.estado <> 'REGISTRADA')
BEGIN
  RAISE_APPLICATION_ERROR(-20030, 'No se puede eliminar la importación ' || :OLD.numero ||
                          ' porque está en estado ' || :OLD.estado);
END trg_importacion_no_borrar;
/

-- EVIDENCIA: objetos PL/SQL creados y sin errores de compilación
SELECT object_name, object_type, status
FROM   user_objects
WHERE  object_type IN ('FUNCTION', 'PROCEDURE', 'TRIGGER')
ORDER  BY object_type, object_name;

SELECT name, type, line, text FROM user_errors ORDER BY name, sequence;
