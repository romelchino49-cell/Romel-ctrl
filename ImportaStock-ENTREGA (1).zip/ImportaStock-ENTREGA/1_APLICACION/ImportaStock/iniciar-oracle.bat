@echo off
echo Iniciando ImportaStock con Oracle (la primera vez tarda 5-10 minutos)...
docker compose -f docker-compose.yml -f docker-compose.oracle.yml up -d --build
echo.
echo App:      http://localhost:4200   (admin1 / Admin123!)
echo Keycloak: http://localhost:8081   (admin / admin)
echo Oracle:   localhost:1522  servicio FREEPDB1  usuario importastock / importastock
echo Ver progreso de Oracle: docker compose logs -f oracle
pause
