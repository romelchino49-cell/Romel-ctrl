@echo off
docker compose up -d --build
echo.
echo App:      http://localhost:4200
echo Keycloak: http://localhost:8081  (admin / admin)
echo La primera vez tarda varios minutos; espera ~1 min a que Keycloak inicie.
pause
