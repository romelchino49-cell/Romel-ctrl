#!/bin/sh
docker compose up -d --build
echo "App: http://localhost:4200  |  Keycloak: http://localhost:8081 (admin/admin)"
